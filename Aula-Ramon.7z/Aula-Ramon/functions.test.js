const {lista} = require("./teste")

test('ordena a lista', () =>{

        const entrada = [10, 2, 4, 5, 9 ,7 , 1, 3, 6, 8]
        const saida = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        expect(lista(entrada)).toEqual(saida)
    
    })

    test('Resolver dimensões', () => {
        const entradaRetangulo = { larg: 2, alt: 4 };
        const entradaCirculo = { raio: 3 };
        const saidaRetangulo = 8;
        const saidaCirculo = 28.274333882308138;
        expect(Calculo_Area(entradaRetangulo, 'retangulo')).toBe(saidaRetangulo);
      });