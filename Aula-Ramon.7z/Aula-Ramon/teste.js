function lista (){
    let numeros = [10, 2, 4, 5, 9 ,7 , 1, 3, 6, 8];
    for (let i = 0; i < numeros.length; i++) {
        for (let j = 0; j < numeros.length - 1; j++) {
            if (numeros[j] > numeros[j + 1]) {
                let temp = numeros[j];
                numeros[j] = numeros[j + 1];
                numeros[j + 1] = temp;
            }
        }
    }
    return(
        numeros
    )
}

console.log(lista());

function Calculo_Area(a, b) {
    let area;
  
    if (b === 'retangulo') {
      const { larg, alt } = a;
      area = larg * alt;
    } else if (b === 'circulo') {
      const { raio } = a;
      area = Math.PI * Math.pow(raio, 2);
    } else {
      throw new Error('Formato não suportado.');
    }
  
    return area;
  }
  
  const dimensaoRetangulo = { larg: 2, alt: 4 };
  const dimensaoCirculo = { raio: 3 };
  
  console.log(Calculo_Area(dimensaoRetangulo, 'retangulo')); 
  console.log(Calculo_Area(dimensaoCirculo, 'circulo'));
  
module.exports = {lista, Calculo_Area}

